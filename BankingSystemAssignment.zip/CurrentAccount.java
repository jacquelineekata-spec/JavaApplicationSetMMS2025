class CurrentAccount extends BankAccount {
    public CurrentAccount(String accountNumber, String accountHolder, double balance) {
        super(accountNumber, accountHolder, balance);
    }
    @Override
    public void withdraw(double amount) {
        if (amount <= balance + 5000) {
            balance -= amount;
            System.out.println("Withdrawal successful.");
        } else {
            System.out.println("Overdraft limit exceeded.");
        }
    }
    @Override
    public double calculateInterest() {
        return balance * 0.02;
    }
}
