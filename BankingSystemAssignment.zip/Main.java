public class Main {
    public static void main(String[] args) {
        SavingsAccount savings = new SavingsAccount("SA001","Jacqueline",50000);
        CurrentAccount current = new CurrentAccount("CA001","John",30000);

        savings.deposit(10000);
        savings.withdraw(5000);
        savings.displayBalance();
        System.out.println("Interest: " + savings.calculateInterest());

        System.out.println();

        current.deposit(5000);
        current.withdraw(35000);
        current.displayBalance();
        System.out.println("Interest: " + current.calculateInterest());
    }
}
